Thanks for using my tool.
To install you need to do the following steps:

https://www.youtube.com/watch?v=hpj8GqPo78E A nice tutorial video how to use and install this.

==========================================================================================

Download chromedriver from this website:
https://chromedriver.chromium.org/downloads

Make sure you select the right version.

Install it in a folder in your C:/ drive under the name "chromedriver" and add it to your path.

Run chromedriver once to start

If you have problems adding items to your path follow this guide:
https://www.architectryan.com/2018/03/17/add-to-the-path-on-windows-10/

In order to make use of this tool you need to install python.
The tool was made in python 3.7 so anything above this will work.
https://www.python.org/downloads/

===========================================================================================

After you have downloaded python you need to start CMD.

Copy and paste the following commands in your command promt to install the python libraries needed.

py -m pip install --user selenium
py -m pip install --user PySimpleGUI

Once pasted hit enter and it will install the packages.

============================================================================================

The installation is now finished and you are ready to go.

Double click on the python file to run it. It should give a new window that will direct you to the login screen.

Once you have logged in click on OK to continue.

Now you will see a list of all the character pages, simply select the last one checked and continue.

It will see if the person is whitelisted or not, then give you options to select if the character is good or not.

After you have finished the list it will automatically send messages to the persons that have been selected.

The only thing you have to do is message the persons that have an invalid backstory and at the end markup your own message.

============================================================================================

Please do not move the pythonfile out of the original folder unless you move every file with it.

The pythonfile will otherwise not work.

============================================================================================

Disclaimer

This is just a tool to make your support work easier.

This tool is not perfect, so any bugs please report to Job on the forums.

I am very good at making a tutorial. If I missed some aspects/if it is still not working. Please send me a pm.

